﻿using CafeT.Folders;
using CafeT.Objects;
using CafeT.Watchers;
using ComputerManager.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComputerManager
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //http://www.fluxbytes.com/csharp/how-to-allow-only-one-application-instance/
            /* Retrieve the application Guid attribute. Alternative you can simply use the application name to initialize the Mutex 
             * but it might be risky as other programs might have similar name and make use of the Mutex class as well. */
            GuidAttribute appGuid = (GuidAttribute)Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(GuidAttribute), true)[0];

            // The boolean that will store the value if Mutex was successfully created which will mean that our application is not already running.
            bool createdNew = true;

            // Initialize the Mutex object.
            using (Mutex mutex = new Mutex(true, appGuid.Value, out createdNew))
            {
                /* If Mutex was created successfully which means our application is not running run the application as usual
                 * or else display a message and close the application.*/
                if (createdNew)
                {
                    // Show the system tray icon.
                    using (ProcessIcon pi = new ProcessIcon())
                    {
                        pi.Display();

                        SmartFolder _folder = new SmartFolder(@"C:\Users\taipm\Downloads");
                        UrlWatcher _urlWatcher = new UrlWatcher("http://www.codeproject.com/", 10000);

                        Application.Run(new FrmMain());
                    }
                }
                else
                {
                    MessageBox.Show("Application is already running");
                }
            }

            //if (Process.GetProcessesByName(Application.ProductName).Length > 1)
            //{
            //    Environment.Exit(1);
            //}

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new FrmMain());
        }
    }
}

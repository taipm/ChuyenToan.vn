﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyncMyCal.Data
{
    public class CalendarId
    {
        public string Provider { get; set; }
        public string DsplayName { get; set; }
        public string InternalId { get; set; }
        public string Description { get; set; }
    }
}

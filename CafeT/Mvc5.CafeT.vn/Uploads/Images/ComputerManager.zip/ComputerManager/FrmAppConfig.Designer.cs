﻿namespace ComputerManager
{
    partial class FrmAppConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ChkStartOnBoot = new System.Windows.Forms.CheckBox();
            this.BtnSaveConfig = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ChkStartOnBoot
            // 
            this.ChkStartOnBoot.AutoSize = true;
            this.ChkStartOnBoot.Location = new System.Drawing.Point(13, 449);
            this.ChkStartOnBoot.Name = "ChkStartOnBoot";
            this.ChkStartOnBoot.Size = new System.Drawing.Size(154, 29);
            this.ChkStartOnBoot.TabIndex = 0;
            this.ChkStartOnBoot.Text = "Auto start ?";
            this.ChkStartOnBoot.UseVisualStyleBackColor = true;
            // 
            // BtnSaveConfig
            // 
            this.BtnSaveConfig.Location = new System.Drawing.Point(778, 424);
            this.BtnSaveConfig.Name = "BtnSaveConfig";
            this.BtnSaveConfig.Size = new System.Drawing.Size(101, 53);
            this.BtnSaveConfig.TabIndex = 1;
            this.BtnSaveConfig.Text = "Save";
            this.BtnSaveConfig.UseVisualStyleBackColor = true;
            this.BtnSaveConfig.Click += new System.EventHandler(this.BtnSaveConfig_Click);
            // 
            // FrmAppConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 490);
            this.Controls.Add(this.BtnSaveConfig);
            this.Controls.Add(this.ChkStartOnBoot);
            this.Name = "FrmAppConfig";
            this.Text = "FrmAppConfig";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox ChkStartOnBoot;
        private System.Windows.Forms.Button BtnSaveConfig;
    }
}
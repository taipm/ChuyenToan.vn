﻿using CafeT.Folders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ComputerManager.Models
{
    //public class TimerModel
    //{

    //}
    public class ComputerModel
    {
        public string BackupFolder { set; get; }
        public SmartFolder Folder { set; get; }

        private Timer TimerClock { set; get; }
       
        public ComputerModel()
        {
            TimerClock = new Timer();
            TimerClock.Elapsed += new ElapsedEventHandler(OnTimer);
            TimerClock.Interval = 1000;
            TimerClock.Enabled = true;

            //Folder = new SmartFolder(BackupFolder);
        }
        
        public void OnTimer(Object source, ElapsedEventArgs e)
        {
            //Your code here 
        }
    }
}

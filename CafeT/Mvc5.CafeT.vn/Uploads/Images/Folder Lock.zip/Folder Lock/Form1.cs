﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Security.AccessControl;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Folder_Lock
{
    public partial class FolderLock : Form
    {
        string defaultText = "Click on Browse and select a folder to lock/unlock";

        public FolderLock()
        {
            InitializeComponent();
            InitialState();
        }

        private void InitialState()
        {
            txtAddress.Text = defaultText;
            txtUserName.Text = "";
            txtUserName.Enabled = false;
            btnBrowse.Select();
            btnLock.Enabled = false;
            btnUnlock.Enabled = false;
            btnClear.Enabled = false;
        }

        private void WorkingState()
        {
            btnLock.Enabled = true;
            btnUnlock.Enabled = true;
            btnClear.Enabled = true;
            txtUserName.Enabled = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutFolderLockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = "Folder Lock 1.01\n\nWindows Code Bits (http:\\\\www.wincodebits.in)\n\n2015 - 2016";
            MessageBox.Show(str,"About Folder Lock 1.01",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtAddress.Text = folderBrowserDialog1.SelectedPath;
                WorkingState();
            }                
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Deny access to this folder to the current user or " + txtUserName.Text + "?" +
                                                  "\nClick 'Yes' for current user and 'No' for " + txtUserName.Text + ".",
                                                  "Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            try
            {
                if (result == DialogResult.Yes)
                {
                    if (txtAddress.Text != "")
                    {
                        FileSecurity fileSecurity = File.GetAccessControl(txtAddress.Text);
                        fileSecurity.AddAccessRule(new FileSystemAccessRule(Environment.UserName, FileSystemRights.FullControl, AccessControlType.Deny));
                        File.SetAccessControl(txtAddress.Text, fileSecurity);

                        MessageBox.Show("The Selected Folder has been LOCKED for " + Environment.UserName, "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        InitialState();
                    }
                }
                else if (result == DialogResult.No)
                {
                    if (txtAddress.Text != "")
                    {
                        FileSecurity fileSecurity = File.GetAccessControl(txtAddress.Text);
                        fileSecurity.AddAccessRule(new FileSystemAccessRule(txtUserName.Text, FileSystemRights.FullControl, AccessControlType.Deny));
                        File.SetAccessControl(txtAddress.Text, fileSecurity);

                        MessageBox.Show("The Selected Folder has been LOCKED for " + txtUserName.Text, "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        InitialState();
                    }
                }
                else
                {
                    MessageBox.Show("Operation Cancelled", "Task Aborted", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch(Exception exception)
            {
                MessageBox.Show(exception.Message + "\nPlease try again and make sure the username entered by you is valid", "An Exception Occurred", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUnlock_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Allow access to this folder to the current user or " + txtUserName.Text + "?" +
                                                  "\nClick 'Yes' for current user and 'No' for " + txtUserName.Text + ".",
                                                  "Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            try
            {
                if (result == DialogResult.Yes)
                {
                    if (txtAddress.Text != "")
                    {
                        FileSecurity fileSecurity = File.GetAccessControl(txtAddress.Text);
                        fileSecurity.RemoveAccessRule(new FileSystemAccessRule(Environment.UserName, FileSystemRights.FullControl, AccessControlType.Deny));
                        File.SetAccessControl(txtAddress.Text, fileSecurity);

                        MessageBox.Show("The Selected Folder has been UNLOCKED for " + Environment.UserName, "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        InitialState();
                    }
                }
                else if (result == DialogResult.No)
                {
                    if (txtAddress.Text != "")
                    {
                        FileSecurity fileSecurity = File.GetAccessControl(txtAddress.Text);
                        fileSecurity.RemoveAccessRule(new FileSystemAccessRule(txtUserName.Text, FileSystemRights.FullControl, AccessControlType.Deny));
                        File.SetAccessControl(txtAddress.Text, fileSecurity);

                        MessageBox.Show("The Selected Folder has been UNLOCKED for " + txtUserName.Text, "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        InitialState();
                    }
                }
                else
                {
                    MessageBox.Show("Operation Cancelled", "Task Aborted", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                }
            }
            catch(Exception exception)
            {
                MessageBox.Show(exception.Message + "\nPlease try again and make sure the username entered by you is valid", "An Exception Occurred", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            InitialState();
        }
    }
}

// DialogOn.cpp : implementation file
//

#include "stdafx.h"
#include "alarm.h"
#include "DialogOn.h"
#include "alarmDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	WM_MYTIMER_INTERN		WM_APP+14
/////////////////////////////////////////////////////////////////////////////
// CDialogOn dialog


CDialogOn::CDialogOn(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogOn::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogOn)
	m_editSnooze = _T("");
	m_editRepeat = _T("");
	//}}AFX_DATA_INIT
	pApp = NULL;
	m_snooze_minute = 1;
	m_repeat_sec = 1;
	isInit = FALSE;
}


void CDialogOn::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogOn)
	DDX_Control(pDX, IDC_SPINREPEAT, m_spinRepeat);
	DDX_Control(pDX, IDC_EDITREPEAT, ctrl_editRepeat);
	DDX_Control(pDX, IDC_SPINSNOOZE, m_spin);
	DDX_Control(pDX, IDOK, m_btn_snooze);
	DDX_Control(pDX, IDC_EDITSNOOZE, ctrl_editSnooze);
	DDX_Text(pDX, IDC_EDITSNOOZE, m_editSnooze);
	DDX_Text(pDX, IDC_EDITREPEAT, m_editRepeat);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogOn, CDialog)
	//{{AFX_MSG_MAP(CDialogOn)
	ON_WM_TIMER()
	ON_EN_UPDATE(IDC_EDITSNOOZE, OnUpdateEditsnooze)
	ON_EN_UPDATE(IDC_EDITREPEAT, OnUpdateEditrepeat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogOn message handlers



BOOL CDialogOn::Create(CWnd* pParentWnd) 
{

	regSection = _T("Alarm_Mathieu");
	pApp = AfxGetApp();
	int ret  = 0;
	ret = CDialog::Create(IDD, pParentWnd);
	isInit = TRUE;
	m_spin.SetRange32(1,90);
	m_spin.SetBase(1);
	m_spinRepeat.SetRange32(1,999);
	m_spinRepeat.SetBase(1);

	/*get delay*/
	regItem = _T("Alarm_snoozetime");
	m_snooze_minute = pApp->GetProfileInt(regSection, regItem, 1);
	m_editSnooze.Format(_T("%d"),m_snooze_minute);
	UpdateData(FALSE);
	/*get repeat*/
	regItem = _T("Alarm_repeattime");
	m_repeat_sec = pApp->GetProfileInt(regSection, regItem, 1);
	m_editRepeat.Format(_T("%d"),m_repeat_sec);
	UpdateData(FALSE);

	this->SetTimer(WM_MYTIMER_INTERN,m_repeat_sec*1000,NULL);


	ModifyStyleEx(NULL,WS_EX_TOPMOST);
	BringWindowToTop( );
	CenterWindow( NULL );

	ctrl_editSnooze.SetLimitText( 2 );
	ctrl_editRepeat.SetLimitText( 2 );
	m_btn_snooze.SetFocus();

	SetWindowPos(&this->wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);

	return ret;

}
void CDialogOn::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == WM_MYTIMER_INTERN)
	StartAlarm();
	CDialog::OnTimer(nIDEvent);
}
void CDialogOn::StartAlarm()
{
	this->KillTimer(WM_MYTIMER_INTERN);
	this->SetTimer(WM_MYTIMER_INTERN,m_repeat_sec*1000,NULL);
	((CAlarmDlg*)this->GetParent())->DoAlarm(m_repeat_sec);

}
void CDialogOn::OnCancel() 
{
	this->KillTimer(WM_MYTIMER_INTERN);
	this->ShowWindow(FALSE);
	((CAlarmDlg*)this->GetParent())->stop_alarm();
	((CAlarmDlg*)this->GetParent())->ShowMain() ;
	((CAlarmDlg*)this->GetParent())->ReInitStartStop(FALSE);
}
void CDialogOn::OnOK() 
{
	this->KillTimer(WM_MYTIMER_INTERN);
	((CAlarmDlg*)this->GetParent())->stop_alarm();
	this->SetTimer(WM_MYTIMER_INTERN,m_snooze_minute*1000*60,NULL);
	this->ShowWindow(FALSE);
}
void CDialogOn::Snooze()
{
	OnOK() ;
}
void CDialogOn::StopAlarm()
{
	OnCancel() ;
	
}
void CDialogOn::OnUpdateEditsnooze() 
{
	if (isInit) {
	UpdateData();
	m_snooze_minute = atoi(m_editSnooze);
	/*set snoozetime*/
	regItem = _T("Alarm_snoozetime");
	pApp->WriteProfileInt(regSection, regItem, m_snooze_minute);
	}
	
}
void CDialogOn::OnUpdateEditrepeat() 
{
	if (isInit) {
	UpdateData();
	m_repeat_sec = atoi(m_editRepeat);
	/*set snoozetime*/
	regItem = _T("Alarm_repeattime");
	pApp->WriteProfileInt(regSection, regItem, m_repeat_sec);
	((CAlarmDlg*)this->GetParent())->stop_alarm();
	this->KillTimer(WM_MYTIMER_INTERN);
	this->SetTimer(WM_MYTIMER_INTERN,m_repeat_sec*1000,NULL);
	StartAlarm();
	}
	
}






//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by alarm.rc
//
#define IDHIDE                          3
#define IDTEST                          4
#define IDBROWSE                        5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ALARM_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDR_MENUPOPUP                   129
#define ICONCLOCK                       131
#define ICONEXPLO1                      133
#define ICONEXPLO2                      134
#define ICONEXPLO3                      135
#define ICONEXPLO4                      136
#define IDD_DIALOG_ON                   137
#define IDC_EDIT_WAVEPATH               1000
#define IDAPPLY                         1001
#define IDC_CHECK_WAVE                  1002
#define IDC_CHECK_WINDOW                1003
#define IDC_COMBO_AMPM                  1005
#define IDC_EDITDELAY                   1009
#define IDC_SPINDELAY                   1010
#define IDC_SPINHOUR                    1011
#define IDC_EDITHOUR                    1012
#define IDC_EDITMIN                     1013
#define IDC_SPINMIN                     1014
#define IDC_CHECKDELAY                  1015
#define IDC_CHECKPRESET                 1016
#define IDC_EDITSNOOZE                  1016
#define IDC_EDITREPEAT                  1017
#define IDC_SPINSNOOZE                  1018
#define IDC_STATICSNOOZE                1019
#define IDC_SPINREPEAT                  1020
#define IDC_CHECK_STARTUP               1020
#define ID_POPUP_SETUP                  32771
#define ID_POPUP_EXIT                   32772
#define ID_POPUP_ABOUTALARM             32773
#define ID_POPUP_SNOOZE                 32774
#define ID_POPUP_STOPALARM              32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

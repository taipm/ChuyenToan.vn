// alarmDlg.h : header file
//

#if !defined(AFX_ALARMDLG_H__9AEBC1FF_408E_4F30_812C_8B8AFE0D5DB5__INCLUDED_)
#define AFX_ALARMDLG_H__9AEBC1FF_408E_4F30_812C_8B8AFE0D5DB5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SystemTray.h"
#include "DialogOn.h"
#include "WinStartup.h"

/////////////////////////////////////////////////////////////////////////////
// CAlarmDlg dialog

class CAlarmDlg : public CDialog
{
// Construction
public:
	CAlarmDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAlarmDlg)
	enum { IDD = IDD_ALARM_DIALOG };
	CButton	ctrl_chkStartup;
	CButton	m_btn_start;
	CComboBox	m_comboAMPM;
	CButton	m_btnBrowse;
	CEdit	m_editPath;
	CEdit	ctrl_editMin;
	CEdit	ctrl_editHour;
	CEdit	ctrl_editDelay;
	CSpinButtonCtrl	m_spinMin;
	CSpinButtonCtrl	m_spinHour;
	CSpinButtonCtrl	m_spinDelay;
	CString	m_wavepath;
	CString	m_editDelay;
	CString	m_editHour;
	CString	m_editMin;
	BOOL	m_chkWave;
	BOOL	m_chkDelay;
	BOOL	m_chkPreset;
	BOOL	m_chkWindow;
	BOOL	m_chkStartup;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAlarmDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
private:
	BOOL isInit;
	BOOL isDelayStarted;
	BOOL isPresetStarted;
	void GetInfo();
	void SetInfo();
	void SetChecked();
	void Load_wave();
	void play_alarm();
	void adjust_hour();
	int IsTimePresetPassed();
	void adjustfor24h();

	
	void OnAnimateTray(int secrepeat);

	void SetAlarm(BOOL onoff);

	HWND m_Audio;
	CString regSection;
	CString regItem;
	int single_delay;
	int single_hour;
	int single_min;
	int single_year;
	int single_month;
	int single_day;

	StartupUser user;
	COleDateTime ActualTime;
	COleDateTime PresetTime;

	CFileDialog* dia_browse;
	CDialogOn* dia_alarm;

public:
	CSystemTray m_TrayIcon;
	BOOL isiconic;

	void ReInitStartStop(BOOL isStarted);
	void stop_alarm();
	void ShowMain();
	void SetDelay(int min=0);
	void SetPreset(BOOL isON);
	void DoAlarm(int secrepeat);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAlarmDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPopupSetup();
	afx_msg void OnPopupExit();
	afx_msg void OnPopupAboutalarm();
	afx_msg void OnHide();
	afx_msg void OnBrowse();
	afx_msg void OnTest();
	afx_msg void OnUpdateEditWavepath();
	afx_msg void OnApply();
	afx_msg void OnUpdateEditdelay();
	afx_msg void OnUpdateEdithour();
	afx_msg void OnUpdateEditmin();
	afx_msg void OnCheckWave();
	afx_msg void OnCheckdelay();
	afx_msg void OnCheckpreset();
	afx_msg void OnSelchangeComboAmpm();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnCheckWindow();
	afx_msg void OnPopupSnooze();
	afx_msg void OnPopupStopalarm();
	afx_msg LRESULT OnTrayNotification(WPARAM wParam, LPARAM lParam);
	virtual void OnCancel();
	afx_msg void OnCheckStartup();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALARMDLG_H__9AEBC1FF_408E_4F30_812C_8B8AFE0D5DB5__INCLUDED_)

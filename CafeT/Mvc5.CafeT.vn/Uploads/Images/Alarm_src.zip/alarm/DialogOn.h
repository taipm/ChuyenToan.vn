#if !defined(AFX_DIALOGON_H__380F9C3E_159C_4B52_BAE4_6D5AB48FA0E1__INCLUDED_)
#define AFX_DIALOGON_H__380F9C3E_159C_4B52_BAE4_6D5AB48FA0E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogOn.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogOn dialog

class CDialogOn : public CDialog
{
// Construction
public:
	CDialogOn(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogOn)
	enum { IDD = IDD_DIALOG_ON };
	CSpinButtonCtrl	m_spinRepeat;
	CEdit	ctrl_editRepeat;
	CSpinButtonCtrl	m_spin;
	CButton	m_btn_snooze;
	CEdit	ctrl_editSnooze;
	CString	m_editSnooze;
	CString	m_editRepeat;
	//}}AFX_DATA

	BOOL isInit;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogOn)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

private:
	CString regSection;
	CString regItem;


		CWinApp* pApp;
public:
	void Snooze();
	void StartAlarm();
	void StopAlarm();
	

		int m_snooze_minute;
		int m_repeat_sec;
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogOn)
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnUpdateEditsnooze();
	afx_msg void OnUpdateEditrepeat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGON_H__380F9C3E_159C_4B52_BAE4_6D5AB48FA0E1__INCLUDED_)

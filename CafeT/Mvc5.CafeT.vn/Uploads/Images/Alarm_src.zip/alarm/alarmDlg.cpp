// alarmDlg.cpp : implementation file
//

#include "stdafx.h"
#include "alarm.h"
#include "alarmDlg.h"

#include <vfw.h>  //for mp3 playing

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	WM_ICON_NOTIFY			WM_APP+10
#define	WM_MYTIMER_DELAY		WM_APP+11
#define	WM_MYTIMER_PRESET		WM_APP+12


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
	
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlarmDlg dialog

CAlarmDlg::CAlarmDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAlarmDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAlarmDlg)
	m_wavepath = _T("");
	m_editDelay = _T("");
	m_editHour = _T("");
	m_editMin = _T("");
	m_chkWave = FALSE;
	m_chkDelay = FALSE;
	m_chkPreset = FALSE;
	m_chkWindow = FALSE;
	m_chkStartup = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(ICONCLOCK);
	isInit = FALSE;
	dia_browse = NULL;
	dia_alarm = NULL;
	isDelayStarted = FALSE;
	isPresetStarted = FALSE;
	m_Audio = NULL;
	isiconic = FALSE;
	m_wavepath = _T("");
	single_delay = 0;
	single_hour = 0;
	single_min = 0;
	single_year = 0;
	single_month = 0;
	single_day = 0;

}

void CAlarmDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAlarmDlg)
	DDX_Control(pDX, IDC_CHECK_STARTUP, ctrl_chkStartup);
	DDX_Control(pDX, IDAPPLY, m_btn_start);
	DDX_Control(pDX, IDC_COMBO_AMPM, m_comboAMPM);
	DDX_Control(pDX, IDBROWSE, m_btnBrowse);
	DDX_Control(pDX, IDC_EDIT_WAVEPATH, m_editPath);
	DDX_Control(pDX, IDC_EDITMIN, ctrl_editMin);
	DDX_Control(pDX, IDC_EDITHOUR, ctrl_editHour);
	DDX_Control(pDX, IDC_EDITDELAY, ctrl_editDelay);
	DDX_Control(pDX, IDC_SPINMIN, m_spinMin);
	DDX_Control(pDX, IDC_SPINHOUR, m_spinHour);
	DDX_Control(pDX, IDC_SPINDELAY, m_spinDelay);
	DDX_Text(pDX, IDC_EDIT_WAVEPATH, m_wavepath);
	DDX_Text(pDX, IDC_EDITDELAY, m_editDelay);
	DDX_Text(pDX, IDC_EDITHOUR, m_editHour);
	DDX_Text(pDX, IDC_EDITMIN, m_editMin);
	DDX_Check(pDX, IDC_CHECK_WAVE, m_chkWave);
	DDX_Check(pDX, IDC_CHECKDELAY, m_chkDelay);
	DDX_Check(pDX, IDC_CHECKPRESET, m_chkPreset);
	DDX_Check(pDX, IDC_CHECK_WINDOW, m_chkWindow);
	DDX_Check(pDX, IDC_CHECK_STARTUP, m_chkStartup);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAlarmDlg, CDialog)
	//{{AFX_MSG_MAP(CAlarmDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_POPUP_SETUP, OnPopupSetup)
	ON_COMMAND(ID_POPUP_EXIT, OnPopupExit)
	ON_COMMAND(ID_POPUP_ABOUTALARM, OnPopupAboutalarm)
	ON_BN_CLICKED(IDHIDE, OnHide)
	ON_BN_CLICKED(IDBROWSE, OnBrowse)
	ON_BN_CLICKED(IDTEST, OnTest)
	ON_EN_UPDATE(IDC_EDIT_WAVEPATH, OnUpdateEditWavepath)
	ON_BN_CLICKED(IDAPPLY, OnApply)
	ON_EN_UPDATE(IDC_EDITDELAY, OnUpdateEditdelay)
	ON_EN_UPDATE(IDC_EDITHOUR, OnUpdateEdithour)
	ON_EN_UPDATE(IDC_EDITMIN, OnUpdateEditmin)
	ON_BN_CLICKED(IDC_CHECK_WAVE, OnCheckWave)
	ON_BN_CLICKED(IDC_CHECKDELAY, OnCheckdelay)
	ON_BN_CLICKED(IDC_CHECKPRESET, OnCheckpreset)
	ON_CBN_SELCHANGE(IDC_COMBO_AMPM, OnSelchangeComboAmpm)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CHECK_WINDOW, OnCheckWindow)
	ON_COMMAND(ID_POPUP_SNOOZE, OnPopupSnooze)
	ON_COMMAND(ID_POPUP_STOPALARM, OnPopupStopalarm)
	ON_BN_CLICKED(IDC_CHECK_STARTUP, OnCheckStartup)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_ICON_NOTIFY, OnTrayNotification)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlarmDlg message handlers

BOOL CAlarmDlg::OnInitDialog()
{
	regSection = _T("Alarm_Mathieu");
	user = CurrentUser;
	CDialog::OnInitDialog();

	m_comboAMPM.ResetContent();
	m_comboAMPM.InitStorage( 3, 16 );
	m_comboAMPM.AddString( "24h" );
	m_comboAMPM.AddString( "AM" );
	m_comboAMPM.AddString( "PM" );
	m_comboAMPM.SetCurSel(0);

	GetInfo();
	if (isiconic)
		OnHide();

	this->KillTimer(WM_MYTIMER_DELAY);
	this->KillTimer(WM_MYTIMER_PRESET);
	

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_spinDelay.SetBase( 1 );
	m_spinHour.SetBase( 1 );
	m_spinMin.SetBase( 1 );
	m_spinDelay.SetRange32( 1,120 );
	m_spinHour.SetRange32( 0,23 );
	m_spinMin.SetRange32( 0,59 );
	m_spinDelay.SetPos( 1 );
	m_spinHour.SetPos( 0 );
	m_spinMin.SetPos( 0 );
	
	

	ctrl_editHour.SetLimitText( 2 );
	ctrl_editMin.SetLimitText( 2 );
	ctrl_editDelay.SetLimitText( 3 );

	CString filter = _T("Sound Files (*.wav;*.mp3)|*.wav; *.mp3|All Files (*.*)|*.*||");
	dia_browse = new CFileDialog(TRUE,NULL,NULL,OFN_FILEMUSTEXIST|OFN_NONETWORKBUTTON|OFN_HIDEREADONLY,filter,this);

	dia_alarm = new CDialogOn(this);
	dia_alarm->Create(this);

	m_TrayIcon.Create(  this,                            // Let icon deal with its own messages
                        WM_ICON_NOTIFY,                  // Icon notify message to use
                        _T("Alarm"),  // tooltip
                        m_hIcon,
                        IDR_MENUPOPUP);
	m_TrayIcon.SetTargetWnd(this);
	
	m_TrayIcon.EnableMenuItem(ID_POPUP_SNOOZE,FALSE);
	m_TrayIcon.SetMenuText(ID_POPUP_STOPALARM,"Start alarm");
	m_TrayIcon.SetMenuDefaultItem(0, TRUE);
	

	SetChecked();
	SetDelay(0);
	isInit = TRUE;
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}
LRESULT CAlarmDlg::OnTrayNotification(WPARAM wParam, LPARAM lParam)
{
	return m_TrayIcon.OnTrayNotification(wParam, lParam);
}
void CAlarmDlg::OnSysCommand(UINT nID, LPARAM lParam)
{	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{	CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else{	CDialog::OnSysCommand(nID, lParam);	}
}
void CAlarmDlg::OnPaint() 
{	if (IsIconic())
	{	CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else{	CDialog::OnPaint();	}
}
HCURSOR CAlarmDlg::OnQueryDragIcon()
{	return (HCURSOR) m_hIcon;}
void CAlarmDlg::OnCancel() 
{
	m_TrayIcon.RemoveIcon();
	CDialog::OnCancel();
}
void CAlarmDlg::OnHide() 
{
	CSystemTray::MinimiseToTray(this);
	isiconic = TRUE;
	SetInfo();
}
void CAlarmDlg::ShowMain()
{
	OnPopupSetup() ;
}
void CAlarmDlg::OnPopupSetup() 
{
	if (isiconic) {
	CSystemTray::MaximiseFromTray(this);
	isiconic = FALSE;
	SetInfo();
	}
}
void CAlarmDlg::OnPopupExit() 
{
	m_TrayIcon.RemoveIcon();
	DestroyWindow();
}
void CAlarmDlg::OnPopupAboutalarm() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


void CAlarmDlg::OnBrowse() 
{
	if (dia_browse){
	if (dia_browse->DoModal() == IDOK) {
	m_wavepath = dia_browse->GetPathName();
	UpdateData(FALSE);
	Load_wave();
	}
	}
	
}

void CAlarmDlg::OnTest() 
{
	if (m_chkWave){
		SetAlarm(TRUE);
	}
}
void CAlarmDlg::GetInfo()
{
	CWinApp* pApp = AfxGetApp();
	/*get wave*/
	regItem = _T("Alarm_wavepath");
	m_wavepath = pApp->GetProfileString(regSection, regItem);
	UpdateData(FALSE);

	/*get delay*/
	regItem = _T("Alarm_singledelay");
	single_delay = pApp->GetProfileInt(regSection, regItem, 1);
	m_editDelay.Format(_T("%d"),single_delay);
	UpdateData(FALSE);

	/*get hour*/
	regItem = _T("Alarm_singlehour");
	single_hour = pApp->GetProfileInt(regSection, regItem, 0);
	m_editHour.Format(_T("%d"),single_hour);
	UpdateData(FALSE);

	/*get min*/
	regItem = _T("Alarm_singleminute");
	single_min = pApp->GetProfileInt(regSection, regItem, 0);
	m_editMin.Format(_T("%d"),single_min);
	UpdateData(FALSE);

	/*get chkWave*/
	regItem = _T("Alarm_chkWave");
	m_chkWave = pApp->GetProfileInt(regSection, regItem, 0);
	UpdateData(FALSE);

	/*get chkDelay*/
	regItem = _T("Alarm_chkDelay");
	m_chkDelay = pApp->GetProfileInt(regSection, regItem, 0);
	UpdateData(FALSE);

	/*get chkPreset*/
	regItem = _T("Alarm_chkPreset");
	m_chkPreset = pApp->GetProfileInt(regSection, regItem, 0);
	UpdateData(FALSE);

	/*get combo AMPM*/
	regItem = _T("Alarm_comboAMPM");
	int pos = pApp->GetProfileInt(regSection, regItem, 0);
	m_comboAMPM.SetCurSel(pos);
	UpdateData(FALSE);

	/*get chkPreset*/
	regItem = _T("Alarm_chkWindow");
	m_chkWindow = pApp->GetProfileInt(regSection, regItem, 0);
	UpdateData(FALSE);

	/*get chkStartup*/
	regItem = _T("Alarm_chkStartup");
	m_chkStartup = pApp->GetProfileInt(regSection, regItem, 0);
	UpdateData(FALSE);

	/*get isHide*/
	regItem = _T("Alarm_isHide");
	isiconic = pApp->GetProfileInt(regSection, regItem, 0);
	UpdateData(FALSE);

	adjustfor24h();

	Load_wave();
}
void CAlarmDlg::SetInfo()
{
	CWinApp* pApp = AfxGetApp();
	/*set wavepath*/
	regItem = _T("Alarm_wavepath");
	pApp->WriteProfileString(regSection, regItem, m_wavepath);

	/*set delay*/
	regItem = _T("Alarm_singledelay");
	pApp->WriteProfileInt(regSection, regItem, single_delay);

	/*set hour*/
	regItem = _T("Alarm_singlehour");
	pApp->WriteProfileInt(regSection, regItem, single_hour);

	/*set min*/
	regItem = _T("Alarm_singleminute");
	pApp->WriteProfileInt(regSection, regItem, single_min);

	/*set chkWave*/
	regItem = _T("Alarm_chkWave");
	pApp->WriteProfileInt(regSection, regItem, m_chkWave);

	/*set chkDelay*/
	regItem = _T("Alarm_chkDelay");
	pApp->WriteProfileInt(regSection, regItem, m_chkDelay);

	/*set chkPreset*/
	regItem = _T("Alarm_chkPreset");
	pApp->WriteProfileInt(regSection, regItem, m_chkPreset);

	/*set combo AMPM*/
	int pos = m_comboAMPM.GetCurSel();
	regItem = _T("Alarm_comboAMPM");
	pApp->WriteProfileInt(regSection, regItem, pos);

	/*set chkWindow*/
	regItem = _T("Alarm_chkWindow");
	pApp->WriteProfileInt(regSection, regItem, m_chkWindow);

	/*get chkStartup*/
	regItem = _T("Alarm_chkStartup");
	pApp->WriteProfileInt(regSection, regItem, m_chkStartup);

	/*get isHide*/
	regItem = _T("Alarm_isHide");
	pApp->WriteProfileInt(regSection, regItem, isiconic);

}
void CAlarmDlg::Load_wave()
{
	MCIWndStop(m_Audio);
	m_Audio = MCIWndCreate(this->GetSafeHwnd(),
			AfxGetInstanceHandle(),
			WS_CHILD | 
			MCIWNDF_NOMENU|
			MCIWNDF_NOPLAYBAR |
			MCIWNDF_NOTIFYMODE | //to notify the parent sending a message
			MCIWNDF_NOAUTOSIZEWINDOW |
			MCIWNDF_NOAUTOSIZEMOVIE  |
			MCIWNDF_NOERRORDLG,
			m_wavepath);

	MCIWndSetInactiveTimer(m_Audio,1);
	MCIWndSetActiveTimer(m_Audio,1);

}
void CAlarmDlg::play_alarm()
{
	if (m_chkWave){
	MCIWndPlayFrom(m_Audio,0);
	}
}
void CAlarmDlg::stop_alarm()
{
	MCIWndStop(m_Audio);
	m_TrayIcon.StopAnimation();
}
void CAlarmDlg::OnUpdateEditWavepath() 
{
	UpdateData();
	SetInfo();
	Load_wave();
}

void CAlarmDlg::OnApply() 
{
	
	if ((m_chkDelay)&&(isDelayStarted == FALSE)) {
		SetDelay(single_delay);
	}
	else{
		SetDelay(0);
	}

	if ((m_chkPreset)&&(isPresetStarted == FALSE)) {
		SetPreset(TRUE);
	}
	else
		SetPreset(FALSE);

	if ((isDelayStarted)||(isPresetStarted)){
		ReInitStartStop(TRUE);
	}

	
}
void CAlarmDlg::OnUpdateEditdelay() 
{
	if (isInit) {
	UpdateData();
	single_delay = atoi(m_editDelay);
	SetInfo();
	}
	
}

void CAlarmDlg::OnUpdateEdithour() 
{
	if (isInit) {
	UpdateData();
	single_hour = atoi(m_editHour);
	SetInfo();
	adjustfor24h();
	}
	
}
void CAlarmDlg::adjustfor24h()
{
	int sel = m_comboAMPM.GetCurSel();

	if (sel == 2)
		single_hour = single_hour + 12;

}

void CAlarmDlg::OnUpdateEditmin()
{
	if (isInit) {
	UpdateData();
	single_min = atoi(m_editMin);
	SetInfo();
	}
	
}
void CAlarmDlg::OnCheckWave() 
{	UpdateData();SetChecked();}
void CAlarmDlg::OnCheckdelay() 
{	UpdateData();SetChecked();}
void CAlarmDlg::OnCheckpreset() 
{	UpdateData();SetChecked();}
void CAlarmDlg::OnCheckStartup() 
{	UpdateData();SetChecked();
	if (m_chkStartup)
		CWinStartup::AddApp(AfxGetApp()->m_hInstance, _T("Alarm_Mathieu_Startup"), user);
	else
		CWinStartup::RemoveApp(_T("Alarm_Mathieu_Startup"), user);
}
void CAlarmDlg::OnCheckWindow() 
{	UpdateData();SetChecked();}
void CAlarmDlg::SetChecked()
{
	if (m_chkWave){
		m_editPath.EnableWindow(TRUE);
		m_btnBrowse.EnableWindow(TRUE);
	}
	else {
		m_editPath.EnableWindow(FALSE);
		m_btnBrowse.EnableWindow(FALSE);
	}
	if (m_chkDelay){
		m_spinDelay.EnableWindow(TRUE);
		ctrl_editDelay.EnableWindow(TRUE);
	}
	else {
		this->KillTimer(WM_MYTIMER_DELAY);
		m_spinDelay.EnableWindow(FALSE);
		ctrl_editDelay.EnableWindow(FALSE);
	}
	if (m_chkPreset){
		m_spinHour.EnableWindow(TRUE);
		m_spinMin.EnableWindow(TRUE);
		ctrl_editHour.EnableWindow(TRUE);
		ctrl_editMin.EnableWindow(TRUE);
		m_comboAMPM.EnableWindow(TRUE);
		ctrl_chkStartup.EnableWindow(TRUE);
		
	}
	else {
		this->KillTimer(WM_MYTIMER_PRESET);
		m_spinHour.EnableWindow(FALSE);
		m_spinMin.EnableWindow(FALSE);
		ctrl_editHour.EnableWindow(FALSE);
		ctrl_editMin.EnableWindow(FALSE);
		m_comboAMPM.EnableWindow(FALSE);
		ctrl_chkStartup.EnableWindow(FALSE);
	}
	SetInfo();

}

void CAlarmDlg::OnSelchangeComboAmpm() 
{	UpdateData();SetInfo();

	int sel = m_comboAMPM.GetCurSel();

	if (sel == 0)
		m_spinHour.SetRange32( 0,23 );
	else
		m_spinHour.SetRange32( 0,11 );

	adjust_hour();
	OnUpdateEditmin() ;
	OnUpdateEdithour() ;


}
void CAlarmDlg::adjust_hour()
{
	int sel = m_comboAMPM.GetCurSel();
	int hour = atoi(m_editHour);

	if ((sel != 0)&&(hour > 11)){
		hour = hour - 12;
		m_editHour.Format(_T("%d"),hour);
		UpdateData(FALSE);
	}
}
int CAlarmDlg::IsTimePresetPassed()
{
	int ret = 0;
	ActualTime = COleDateTime::GetCurrentTime();
	single_year = ActualTime.GetYear();
	single_month = ActualTime.GetMonth();
	single_day = ActualTime.GetDay();
	PresetTime.SetDateTime( single_year, single_month,single_day,single_hour,single_min,0);

	if (PresetTime==ActualTime)
		ret = 1;

	return ret;
}
void CAlarmDlg::SetDelay(int min)
{
	if (min > 0) {
	this->SetTimer(WM_MYTIMER_DELAY,min*1000*60,NULL);
	isDelayStarted = TRUE;
	}
	else {
		this->KillTimer(WM_MYTIMER_DELAY);
		dia_alarm->StopAlarm();
		ReInitStartStop(FALSE);
		isDelayStarted = FALSE;
	}
}
void CAlarmDlg::SetPreset(BOOL isON)
{
	if (isON) {
	this->SetTimer(WM_MYTIMER_PRESET,1000,NULL);
	isPresetStarted = TRUE;
	}
	else {
		this->KillTimer(WM_MYTIMER_PRESET);
		dia_alarm->StopAlarm();
		ReInitStartStop(FALSE);
		isPresetStarted = FALSE;
	}

}
void CAlarmDlg::ReInitStartStop(BOOL isStarted)
{
	if (isStarted){
	m_btn_start.SetWindowText("Stop");
	UpdateData(FALSE);
	m_TrayIcon.SetMenuText(ID_POPUP_STOPALARM,"Stop alarm");
	UpdateData(FALSE);
	}
	else {
	m_btn_start.SetWindowText("Start");
	UpdateData(FALSE);
	m_TrayIcon.SetMenuText(ID_POPUP_STOPALARM,"Start alarm");
	UpdateData(FALSE);
	}

}
void CAlarmDlg::OnAnimateTray(int secrepeat)
{
	m_TrayIcon.SetIconList(ICONEXPLO1, ICONEXPLO4);
	m_TrayIcon.Animate(50,secrepeat);
	

}
void CAlarmDlg::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == WM_MYTIMER_DELAY){
		SetAlarm(TRUE);
		this->KillTimer(WM_MYTIMER_DELAY);
	}
	else if (nIDEvent == WM_MYTIMER_PRESET){
		if (isPresetStarted){
			if (IsTimePresetPassed()) {
			SetAlarm(TRUE);
			this->KillTimer(WM_MYTIMER_PRESET);
			}
		}

	}

	CDialog::OnTimer(nIDEvent);

}
void CAlarmDlg::SetAlarm(BOOL onoff)
{
	if (TRUE){
	dia_alarm->StartAlarm();
	}

}
void CAlarmDlg::DoAlarm(int secrepeat)
{
	OnAnimateTray(secrepeat);
	play_alarm();
	if (m_chkWindow)
		dia_alarm->ShowWindow(TRUE);
	m_TrayIcon.EnableMenuItem(ID_POPUP_SNOOZE,TRUE);


}


void CAlarmDlg::OnPopupSnooze() 
{
	dia_alarm->Snooze() ;
	m_TrayIcon.EnableMenuItem(ID_POPUP_SNOOZE,FALSE);
	
}

void CAlarmDlg::OnPopupStopalarm() 
{
	OnApply() ;
		
	
}




